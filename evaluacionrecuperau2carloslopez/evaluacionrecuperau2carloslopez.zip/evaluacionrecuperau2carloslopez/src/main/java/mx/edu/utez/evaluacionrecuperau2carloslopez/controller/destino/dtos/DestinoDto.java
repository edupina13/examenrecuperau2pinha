package mx.edu.utez.evaluacionrecuperau2carloslopez.controller.destino.dtos;

public class DestinoDto {
}
