package mx.edu.utez.evaluacionrecuperau2carloslopez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evaluacionrecuperau2carloslopezApplication {

	public static void main(String[] args) {
		SpringApplication.run(Evaluacionrecuperau2carloslopezApplication.class, args);
	}

}
